module.exports = {
  tokens: "8466955308:AAFvcINAzqScIIRh1yxwKD2XnmAK-XwZOQo",  // Masukin Bot token kamu
  owners: "7680882337", // Masukin ID Telegram kamu
  port: "8080", // Masukin Port panel kamu 
  ipvps: "https://zemaaprivate.zonapanel.web.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/